/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package errordebug;

import com.hpt150030.beans.SearchBookResultBean;
import com.hpt150030.utilities.Constants;
import com.hpt150030.utilities.DatabaseConnection;
import com.hpt150030.utilities.STATUS_TYPE;



public class Errordebug {

    public static void main(String[] args) {
        
        
        
    }
    
}
